﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;

namespace DriveBCWebsite
{
    class Program
    {
        static void Main(string[] args)
        {
            IWebDriver driver = new ChromeDriver();
            driver.Navigate().GoToUrl("https://www.bellevuecollege.edu");

            //Timeout in case FindElement fails when page fails to render
            //driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);

            //One element for everything in this simple version.  Generally not a good idea.
            IWebElement ele;

            //On the home page
            ele = driver.FindElement(By.CssSelector("#nav-home"));

            Console.WriteLine($"Current page: \"{ele.Text}\"");

            //Navigate to Classes page
            ele = driver.FindElement(By.CssSelector("#nav-classes > a"));
            ele.Click();

            //On Classes page
            ele = driver.FindElement(By.CssSelector("#site-header > p > a"));
            Console.WriteLine($"Current page: \"{ele.Text}\"");

            //Select Winter quarter
            ele = driver.FindElement(By.Id("seach-quarter-select"));
            SelectElement s = new SelectElement(ele);
            s.SelectByValue("Winter2020");

            //Search for ISIT 324
            ele = driver.FindElement(By.CssSelector("#search-keyword"));
            ele.SendKeys("ISIT 324");
            ele = driver.FindElement(By.CssSelector("#submitSearchForm > div > div > span > button"));
            ele.Click();

            //Pick out title of first search result 
            ele = driver.FindElement(By.CssSelector("#content > h3 > a"));
            Console.WriteLine($"First result from search is {ele.Text}");

            //On search result page
            ele.Click();

            //On ISIT 324 detail page
            ele = driver.FindElement(By.CssSelector("#content > h1"));
            string tempText = ele.Text;
            ele = driver.FindElement(By.CssSelector("#content > h2:nth-child(2)"));
            tempText += " >> " + ele.Text;
            Console.WriteLine($"Current page: \"{tempText}\"");

            //Navigate to Final Exam Schedule
            ele = driver.FindElement(By.CssSelector("#main > div.row > div > div > div.container > div.well.classes-links > div > div:nth-child(2) > ul > li:nth-child(1) > a"));
            ele.Click();

            //On Final Exam Page
            ele = driver.FindElement(By.CssSelector("#post-43 > div > h1"));
            Console.WriteLine($"Current page: \"{ele.Text}\"");

            //Search for 'cafeteria'
            ele = driver.FindElement(By.Id("college-search-field"));
            ele.SendKeys("  cafeteria");  //Two spaces required because of auto-complete anomaly
            ele = driver.FindElement(By.CssSelector("#college-search-submit"));
            ele.Click();

            //On Search Results Page
            ele = driver.FindElement(By.CssSelector("#results-container > h2:nth-child(1) > a"));
            Console.WriteLine($"First result is {ele.Text}");

            //Take a screenshot
            ele = driver.FindElement(By.CssSelector("#site-header > p > a"));
            try
            {
                //Take the screenshot
                Screenshot image = ((ITakesScreenshot)driver).GetScreenshot();
                //Save the screenshot
                string fileName = ($"C:\\users\\denni\\desktop\\{ele.Text}.png");
                image.SaveAsFile(fileName, ScreenshotImageFormat.Png);
                Console.WriteLine($"Took a pic of {ele.Text}.  It's at {fileName}");
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }

            //Go to blank Search page
            driver.Navigate().Back();

            //On Search page
            ele = driver.FindElement(By.CssSelector("#site-header > p > a"));
            Console.WriteLine($"Current page: \"{ele.Text}\"");

            Console.ReadKey();
            driver.Quit();

        }
    }
}
