﻿using SpacecraftInterface;

namespace WeatherAnalysis
{
    public interface IWeather
    {
        double GetTemperature();
    }
    public class Weather : IWeather
    {
        public double GetTemperature()
        {
            return Telemetry.GetTempFromSpacecraft();
        }

    }

    public static class WeatherUtilities
    {
        public static string JudgeWeatherByWaterState(IWeather w)
        {
            double tempCelsius = w.GetTemperature();
            if(tempCelsius < -273)
            {
                throw new TooColdException.ColderThanAbsoluteZeroException();
            }
            else if(tempCelsius <= 0)
            {
                return ("Freezing");
            }
            else if(tempCelsius > 99)
            {
                return ("Boiling");
            }
            else
            {
                return ("Wet");
            }
        }
    }
}
