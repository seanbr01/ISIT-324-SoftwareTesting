﻿namespace SpacecraftInterface
{
    public static class Telemetry
    {
        public static double GetTempFromSpacecraft()
        {
            //This is supposed to be a routine that invokes another class to retrieve a 
            //temperature (in Celsius) from a spacecraft wandering around the solar system.
            //In order to enable testing, it's just a stub.

            return 0;
        }

    }
}