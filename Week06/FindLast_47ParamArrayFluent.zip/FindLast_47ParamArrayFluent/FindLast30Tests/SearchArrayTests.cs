﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using FindLast30;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SUT = FindLast30.SearchArray;
using FluentAssertions;

namespace FindLast30.Tests
{
    [TestClass()]
    public class FindLastTest_Should
    {
        [DataTestMethod]
        [DataRow(0,2, new int[] { 2, 3, 5 })]
        [DataRow(1,3, new int[] { 2, 3, 5 })]
        [DataRow(2,5, new int[] { 2, 3, 5 })]

        public void ReturnIndex_ForSearchValueInArray(int expectedResult, int x, int[] testArray)
        {
            //Arrange

            //Act
            int result = SUT.FindLast(testArray, x);

            //Assert
            //Assert.AreEqual(expectedResult, result);
            expectedResult.Should().Be(result);
        }

        [TestMethod]
        public void ReturnMinus1_ForSearchValueNotInArray()
        {
            //Arrange
            int[] x = new int[] { 2, 3, 5 };
            int y = 7;

            //Act
            int result = SUT.FindLast(x, y);

            //Assert
            //Assert.AreEqual(result, -1);
            result.Should().Be(-1);
        }

        [TestMethod]
        public void ThrowNullReferenceException_WhenArrayIsNull()
        {
            //Arrange
            int[] x = null;
            int y = 7;

            //Act-Assert
            Action act = () => SUT.FindLast(x, y);

            //Assert
            //Assert.ThrowsException<NullReferenceException>(() => SUT.FindLast(x, y));
            act.Should().Throw<NullReferenceException>();  

        }


    }
}