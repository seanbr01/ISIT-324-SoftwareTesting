﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FindLast30
{
    public class SearchArray
    {

        public static int FindLast(int[] x, int y)
        {
            for (int i = x.Length - 1; i > 0; i--)  //Incorrect
            //for (int i = x.Length - 1; i >= 0; i--)   //Correct
            {
                if (x[i] == y)
                {
                    return i;
                }
            }
            return -1;
        }

    }
}
